<?php
        $n = $_POST['numero'];
        $divisor = 2;
        $total = "";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <title>Document</title>
</head>
<body>
    <div class="container">
       <h3>Resultado</h3>
    </div>
    <div class="container">
        
<?php
        while($n != 1){
            if($n % $divisor == 0){
                $n = $n / $divisor;
                $total = $total . $divisor;
                if($n != 1){
                    $total = $total . " x ";
                }
            }
            else{
                $divisor++;
            }
        }

        echo "<h4>$total</h4>";
?>
    </div>
</body>
</html>