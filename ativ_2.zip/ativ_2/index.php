<?php
        $n_1 = $_POST['num_1'];
        $n_2 = $_POST['num_2'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <title>Document</title>
</head>
<body>
    <div class="container">
       <h3>Resultado do MDC por Euclides</h3>
    </div>
    <div class="container">
        
<?php

    if($n_1 > $n_2){
        $dividendo = $n_1;
        $divisor = $n_2;
    }else{
        $dividendo = $n_2;
        $divisor = $n_1;
    }
    if($dividendo % $divisor == 0){
        $resultado = $divisor;
        echo "<h4>$resultado</h4>";
    }else{
        while($dividendo % $divisor != 0) {
            $resto = $dividendo % $divisor;
            $dividendo = $divisor;
            $divisor = $resto;
            }
        $resultado = $divisor;
        echo "<h4>$resultado</h4>";
    }
        
?>
    </div>
</body>
</html>