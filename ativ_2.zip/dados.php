<?php
        $valor = $_POST['valor'];
        $periodo = $_POST['periodo'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <title>Cálculo do Empréstimo</title>
</head>
<body>
    <div class="container">
       <nav class="navbar navbar-light bg-light">
            <a class="navbar-brand" href="#">
                <img src="imagem/logo.png" width="30" height="30" alt="">
            </a>
        </nav>
    </div>
    <div class="container">
        <div class="jumbotron">
            <p class="h3 text-center py-4">Rendimento mensal: </p>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-3">Mês</div>
            <div class="col-md-6">Valor inicial</div>
            <div class="col-md-3">Valor atualizado</div>
    </div>
<?php
    $juros = 0.02;
    for($i = 1; $i <= $periodo; $i++){
        echo "<div class='row'>";
            echo "<div class='col-md-3'> $i </div>";
            echo "<div class='col-md-6'> R$ " . number_format($valor, 2, ',', '.' ) . "</div>";
            $valor = $valor + ($valor * $juros);
            echo "<div class='col-md-3'> R$ " . number_format($valor, 2, ',', '.' ) . "</div>";
        echo "</div>";
    }
?>
    <div class="container py-4">
        <div class="row">
            <a class="btn btn-primary" href="formulario.html">Novo Cálculo</a>
        </div>
    </div>

</body>
</html>