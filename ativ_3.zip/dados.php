<?php
    $dados[] = array("nome" => "Miranda", "idade" => 54, "estilo" => "Rock");
    $dados[] = array("nome" => "Álvaro", "idade" => 85, "estilo" => "Rock");
    $dados[] = array("nome" => "Costa", "idade" => 20, "estilo" => "K-pop");
    $dados[] = array("nome" => "Tales", "idade" => 73, "estilo" => "MPB");
    $dados[] = array("nome" => "João Humberto Frnacisco", "idade" => 13, "estilo" => "Bossa Nova");
    $dados[] = array("nome" => "Cougo", "idade" => 7, "estilo" => "Rock");
?>