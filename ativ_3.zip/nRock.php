<?php
    include "dados.php";
    function filtro($array, $valor){
        $resultado = array();
            foreach($array as $a){
                    if($a['estilo'] != $valor)
                        $resultado[] = $a;
            }
        return $resultado;
    }
    $rock = filtro($dados, 'Rock');
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <title>Document</title>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand" href="#">Utilizando Arrays em PHP</a>
    </nav>

    <div class="jumbotron bg-light">
        <div class="container">
          <h1 class="display-3">Manipulação de Arrays em PHP</h1>
          <p>Exibindo todos os dados cadastrados das pessoas que não gostam de rock.</p>
        </div>
    </div>
    <table class="table table-striped">
        <thead>
            <tr>
                <th scope="col">Nome</th>
                <th scope="col">Idade</th>
                <th scope="col">Estilo preferido</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($rock as $linha => $item):?>
                <tr>
                    <th scope="row"><?php echo $item['nome'] ?></th>
                    <td><?php echo $item['idade'] ?></td>
                    <td><?php echo $item['estilo'] ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>

</body>

</html>