<?php

    function calcularIdade($data){
        $today = new DateTime();
        $diff = $today->diff(new DateTime($data));
    
        return $diff->y;
        }

    function cmp($a, $b){
        return $a["Idade"] < $b["Idade"];
        }

    $array = array(
        array("Nome" => $_POST['nome1'], "Idade" => calcularIdade($_POST['data1'])),
        array("Nome" => $_POST['nome2'], "Idade" => calcularIdade($_POST['data2'])),
        array("Nome" => $_POST['nome3'], "Idade" => calcularIdade($_POST['data3'])),
        array("Nome" => $_POST['nome4'], "Idade" => calcularIdade($_POST['data4'])));



    usort($array, "cmp")
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./bootstrap/css/bootstrap.min.css">
</head>

<body>

    <div class="container">
        <nav class="p-2 navbar navbar-light bg-light">
            <a class="navbar-brand" href="#">
                <img src="imagens/Bootstrap_logo.svg" width="30" height="30" alt="">
            </a>
        </nav>

        <h1>Exibindo dados em forma descrescente de idade</h1>

    </div>

    <div class="jumbotron"></div>

    <div class="container">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th scope="col">Nome</th>
                    <th scope="col">Idade</th>
                </tr>
            </thead>
            <tbody>

                <?php foreach($array as $linha => $item):?>
                <tr>
                    <th scope="row">
                        <?php echo $item['Nome'] ?>
                    </th>
                    <th scope="row">
                        <?php echo $item['Idade'] ?>
                    </th>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

</body>

</html>